//
// timing.h
//

#ifndef TIMING_H_INCLUDED
#define TIMING_H_INCLUDED

double wtime();

#endif // TIMING_H_IINCLUDED
